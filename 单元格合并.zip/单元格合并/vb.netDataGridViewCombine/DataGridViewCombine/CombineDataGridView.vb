﻿Module CombineDataGridView
    ''' <summary>CombineDataGridView</summary>	
    ''' <remarks>								
    ''' 処理内容:								
    ''' CombineDataGridView								
    ''' 																
    ''' </remarks>	
    Public Class CombineDataGridView
        Private data As New List(Of Rectangle)
        Private Dgv As DataGridView
        ''' <summary>New</summary>	
        ''' <param name="_dgv">DataGridView</param>
        ''' <remarks>								
        ''' 処理内容:
        ''' 新的[datagridview]控件
        ''' 
        ''' New								
        ''' 															
        ''' </remarks>	
        Public Sub New(ByVal _dgv As DataGridView)
            Me.Dgv = _dgv
            AddHandler _dgv.CellPainting, AddressOf DGV_CellPainting
        End Sub
        ''' <summary>Add</summary>	
        ''' <param name="_rect">Rectangle</param>
        ''' <param name="color">Color</param>
        ''' <remarks>								
        ''' 処理内容:
        ''' 添加重绘的单元格
        ''' 
        ''' Add								
        ''' 															
        ''' </remarks>	
        Public Sub Add(ByVal _rect As Rectangle, ByVal color As Color)

            Me.data.Add(_rect)
            Me.SetCellEnabled(_rect, color)
        End Sub
        ''' <summary>Add</summary>	
        ''' <param name="_top">Integer</param>
        ''' <param name="_left">Integer</param>
        ''' <param name="_bottom">Integer</param>
        ''' <param name="_right">Integer</param>
        ''' <param name="color">Color</param>
        ''' <remarks>								
        ''' 処理内容:
        ''' 添加重绘的单元格
        ''' 
        ''' Add								
        ''' 															
        ''' </remarks>	
        Public Sub Add(ByVal _top As Integer, ByVal _left As Integer, ByVal _bottom As Integer, ByVal _right As Integer, ByVal color As Color)
            Me.data.Add(New Rectangle(_top, _left, _bottom, _right))
            Me.SetCellEnabled(New Rectangle(_top, _left, _bottom, _right), color)
        End Sub
        ''' <summary>Add</summary>	
        ''' <param name="_rect">Rectangle</param>
        ''' <param name="color">Color</param>
        ''' <remarks>								
        ''' 処理内容:
        ''' 单元格重绘
        ''' 
        ''' SetCellEnabled								
        ''' 															
        ''' </remarks>
        Private Sub SetCellEnabled(ByVal _rect As Rectangle, ByVal color As Color)
            Dim i, j As Integer

            For i = _rect.Top To _rect.Bottom - 1
                For j = _rect.Left To _rect.Right - 1
                    If i >= 0 Then
                        Me.Dgv.Rows(i).Cells(j).ReadOnly = True
                        Me.Dgv.Rows(i).Cells(j).Style.BackColor = color   '设置单元格颜色 
                    End If
                Next
            Next
            '设置非标题行单元格的可编辑位置为左上角
            If _rect.Top > -1 Then
                Me.Dgv.Rows(_rect.Top).Cells(_rect.Left).ReadOnly = False
            End If

        End Sub
        ''' <summary>InRects</summary>	
        ''' <param name="rowIndex">Integer</param>
        ''' <param name="colIndex">Integer</param>
        ''' <remarks>								
        ''' 処理内容:
        ''' 获取绘制单元格的相对位置
        ''' 
        '''InRects
        '''
        '''</remarks>							
        Private Function InRects(ByVal rowIndex As Integer, ByVal colIndex As Integer) As Integer
            Dim i As Integer
            For i = 0 To Me.data.Count - 1
                If (rowIndex >= Me.data(i).Top And rowIndex < (Me.data(i).Top + Me.data(i).Height) And colIndex >= Me.data(i).Left And colIndex < (Me.data(i).Left + Me.data(i).Width)) Then
                    Return i
                End If
            Next
            Return -1
        End Function
        ''' <summary>DGV_CellPainting</summary>	
        ''' <param name="sender">Object</param>
        ''' <param name="e">DataGridViewCellPaintingEventArgs</param>
        ''' <remarks>								
        ''' 処理内容:
        ''' [datagridview]再描画
        ''' 
        ''' DGV_CellPainting
        ''' 
        ''' </remarks>
        Private Sub DGV_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs)
            Dim i As Integer
            Using gridBrush As Brush = New SolidBrush(Me.Dgv.GridColor), backColorBrush As SolidBrush = New SolidBrush(e.CellStyle.BackColor)
                Using gridLinePen = New Pen(gridBrush)
                    If Me.data.Count = 0 Then Return
                    Dim index As Integer = Me.InRects(e.RowIndex, e.ColumnIndex)
                    If index = -1 Then Return
                    e.Graphics.FillRectangle(backColorBrush, e.CellBounds)
                    If e.ColumnIndex = 0 Then e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Left, e.CellBounds.Top)
                    If e.RowIndex = Me.data(index).Bottom - 1 Then e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1) '画出底线
                    If e.ColumnIndex = Me.data(index).Right - 1 Then '画出正确的线条
                        e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1)
                    End If

                    e.Handled = True
                    For i = 0 To Me.data.Count - 1
                        Dim rect1 As Rectangle = Me.Dgv.GetCellDisplayRectangle(Me.data(i).Left, Me.data(i).Top, False)
                        Dim rect2 As Rectangle = Me.Dgv.GetCellDisplayRectangle(Me.data(i).Right - 1, Me.data(i).Bottom - 1, False)
                        Dim rect As New Rectangle(rect1.Left, rect1.Top, rect2.Right - rect1.Left, rect2.Bottom - rect1.Top)
                        Dim text As String = ""
                        Try
                            If Me.data(i).Top >= 0 Then
                                If Not IsNothing(Me.Dgv.Rows(Me.data(i).Top).Cells(Me.data(i).Left).Value) And Not IsDBNull(Me.Dgv.Rows(Me.data(i).Top).Cells(Me.data(i).Left).Value) Then
                                    text = Me.Dgv.Rows(Me.data(i).Top).Cells(Me.data(i).Left).Value.ToString().Trim()
                                End If

                            Else
                                text = Me.Dgv.Columns(Me.data(i).Left).HeaderText
                            End If
                        Catch ex As Exception
                            text = ""
                        End Try
                        Dim sz As System.Drawing.SizeF = e.Graphics.MeasureString(text, e.CellStyle.Font)
                        e.Graphics.DrawString(text, New Font("ＭＳ ゴシック", 9, FontStyle.Bold), New SolidBrush(e.CellStyle.ForeColor), rect.Left + (rect.Width - sz.Width) / 2, rect.Top + (rect.Height - sz.Height) / 2, StringFormat.GenericDefault)
                    Next
                End Using
            End Using
        End Sub

    End Class
End Module
