﻿Public Class CombineDataGridView
    Private data As New List(Of Rectangle)
    Private Dgv As DataGridView
    Public Sub New(ByVal _dgv As DataGridView)
        Me.Dgv = _dgv
        AddHandler _dgv.CellPainting, AddressOf DGV_CellPainting
    End Sub

    Public Sub Add(ByVal _rect As Rectangle)
        Me.data.Add(_rect)
        Me.SetCellEnabled(_rect)
    End Sub

    Public Sub Add(ByVal _top As Integer, ByVal _left As Integer, ByVal _bottom As Integer, ByVal _right As Integer)
        Me.data.Add(New Rectangle(_top, _left, _bottom, _right))
        Me.SetCellEnabled(New Rectangle(_top, _left, _bottom, _right))
    End Sub

    Private Sub SetCellEnabled(ByVal _rect As Rectangle)
        Dim i, j As Integer
        For i = _rect.Top To _rect.Bottom - 1
            For j = _rect.Left To _rect.Right - 1
                If i > 0 Then
                    Me.Dgv.Rows(i).Cells(j).ReadOnly = True
                    Me.Dgv.Rows(i).Cells(j).Style.BackColor = Color.LightGreen '设置合并后 颜色
                End If
            Next
        Next
    End Sub

    Private Function InRects(ByVal rowIndex As Integer, ByVal colIndex As Integer) As Integer
        Dim i As Integer
        For i = 0 To Me.data.Count - 1
            'If Me.data(i).InRect(rowIndex, colIndex) Then Return i
            If (rowIndex >= Me.data(i).Top And rowIndex < (Me.data(i).Top + Me.data(i).Height) And colIndex >= Me.data(i).Left And colIndex < (Me.data(i).Left + Me.data(i).Width)) Then
                Return i
            End If

        Next
        Return -1
    End Function


    Private Sub DGV_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs)
        Dim i As Integer
        Using gridBrush As Brush = New SolidBrush(Me.Dgv.GridColor), backColorBrush As SolidBrush = New SolidBrush(e.CellStyle.BackColor)
            Using gridLinePen = New Pen(gridBrush)
                If Me.data.Count = 0 Then Return
                Dim index As Integer = Me.InRects(e.RowIndex, e.ColumnIndex)
                If index = -1 Then Return
                e.Graphics.FillRectangle(backColorBrush, e.CellBounds)
                If e.ColumnIndex = 0 Then e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Left, e.CellBounds.Top)
                If e.RowIndex = Me.data(index).Bottom - 1 Then e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1) '画底线
                If e.ColumnIndex = Me.data(index).Right - 1 Then '画右边线
                    e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1)
                End If


                e.Handled = True
                For i = 0 To Me.data.Count - 1
                    Dim rect1 As Rectangle = Me.Dgv.GetCellDisplayRectangle(Me.data(i).Left, Me.data(i).Top, False)
                    Dim rect2 As Rectangle = Me.Dgv.GetCellDisplayRectangle(Me.data(i).Right - 1, Me.data(i).Bottom - 1, False)
                    Dim rect As New Rectangle(rect1.Left, rect1.Top, rect2.Right - rect1.Left, rect2.Bottom - rect1.Top)
                    Dim text As String
                    Try
                        If Me.data(i).Top > 0 Then
                            text = Me.Dgv.Rows(Me.data(i).Top).Cells(Me.data(i).Left).Value.ToString().Trim()
                        Else
                            text = Me.Dgv.Columns(Me.data(i).Left).HeaderText
                        End If
                    Catch ex As Exception
                        text = ""
                    End Try
                    Dim sz As System.Drawing.SizeF = e.Graphics.MeasureString(text, e.CellStyle.Font)
                    e.Graphics.DrawString(text, e.CellStyle.Font, New SolidBrush(e.CellStyle.ForeColor), rect.Left + (rect.Width - sz.Width) / 2, rect.Top + (rect.Height - sz.Height) / 2, StringFormat.GenericDefault)
                Next
            End Using
        End Using
    End Sub
End Class
